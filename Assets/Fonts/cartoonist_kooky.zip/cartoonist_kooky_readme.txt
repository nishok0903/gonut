The cartoonist kooky font is not to be redistributed without
express, written consent.  Use of this font in ANY
commercial art purpose (such as advertising, magazine 
layouts, etc.) requires commercial license of this font.

Such individual license of this font does not entitle the 
user to redistribute, repackage, or otherwise violate copyrights.

Non-commercial, personal use is permitted without registration.  

Conversion of this font for commercial re-release without
license will therefore constitute a violation of the
copyrights and legal action will be taken against violators.

Likewise, use of images from this font in t-shirts, posters,
corporate logos, etc. would constitute a violation of copyrights.
Those applications are NOT permitted within the license of the
font for individual commercial use, and payment and terms of
license of images will have to be arranged with the author.

(You shouldn't make money off my artwork without paying for it.)

Inclusion of this font in Windows themes, software application
packages, or other redistributions is strictly prohibited
without express permission of the author.

Emoticons fonts � copyright 2002-2009 George Edward Purdy
george_edward_purdy@hotmail.com
http://purdydesign.com

This file must be distributed with this font.
